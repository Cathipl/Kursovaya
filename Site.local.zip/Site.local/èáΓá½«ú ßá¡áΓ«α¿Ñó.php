<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Каталог санаториев</title>
<link rel="stylesheet" type="text/css" href="Lab_1.css">
</head>
<body>
<header class="Header">
<div class="Name"><h1>ЛУЧШИЕ САНАТОРИИ ЮГА РОССИИ</h1></div>
<div class="nav">
<a href="Index.htm">Главная</a>
<a href="#">Каталог санаториев</a>
<a href="Контакты.php">Контакты</a>
<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="SignUp">Авторизация
</button>
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="SignUp">Регистрация
</button>
<?php if($_COOKIE['admin'] != ''): ?>
    <button onclick="document.getElementById('id25').style.display='block'" style="width:auto;" class="SignUp">Админ
</button>
<?php endif; ?>
</div>

<div id="id01" class="modal">
  <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content" action="registration.php" method="post">
<div class="container">
<h1>Регистрация</h1>
<p>Заполните эти поля для создания аккаунта.</p>
<hr>
<label for="login"><b>Логин</b></label>
<input type="text" placeholder="Введите логин" name="login" required>

<label for="psw"><b>Пароль</b></label>
<input type="password" placeholder="Введите пароль" name="psw" required style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1;">
      
<label for="email"><b>Адрес электронной почты</b></label>
<input type="email" placeholder="Введите адрес электронной почты" name="email" required>
<div class="clearfix">
<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Регистрация</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id01');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>
<div id="id02" class="modal">
<span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">×</span>

<form class="modal-content" action="authorization.php" method="post">
<div class="container">
<h1>Авторизация</h1>
<p>Пожалуйста заполните эти поля для входа в аккаунт.</p>
<hr>
<label for="login"><b>Введите логин</b></label>
<input type="text" placeholder="Введите логин" name="login" required>

<label for="psw"><b>Пароль</b></label>
<input type="password" placeholder="Введите пароль" name="psw" required style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1;">


<div class="clearfix">
<button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Авторизация</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id02');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>



<div id="id25" class="modal">
  <span onclick="document.getElementById('id25').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content">
<div class="container">
<h1>Администратор</h1>
<hr>

<?php
$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $sql = "SELECT * FROM `turist`";
    $result = mysqli_query($mysql,$sql);

    while($turist = $result -> fetch_assoc()){
    print_r("<p>" ."<b>"."Логин: " ."</b>".$turist['Login'] ."</p>");
    print_r("<p>"."<b>" ."E-mail: " ."</b>".$turist['E-mail'] ."</p>");
    print_r("<p>" ."<b>"."ФИО: " ."</b>".$turist['FIO'] ."</p>");
    print_r("<p>" ."<b>"."Документ удостоверяющий личность: " ."</b>".$turist['Document'] ."</p>");
    print_r("<p>" ."<b>"."Телефон: " ."</b>".$turist['Telefon'] ."</p>");
    print_r("<p>" ."<b>"."Количество забронированных путевок: " ."</b>".$turist['Kol_put'] ."</p>");
    print_r("<hr>");
    }
?>

</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id25');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>



</header>

<form class="search" action="Каталог санаториев.php" method="post">
  <hr class="hre">
  <input name="s" placeholder="Введите название санатория или города" type="search">
  <button class="search1" type="submit">Поиск</button>
</form>
<?php

$mysqli = new mysqli("localhost","mysql","mysql","bronirovanie");
$mysqli->query( "SET NAMES 'utf8'");
$object = mb_strtolower(trim($_POST["s"]));
$dd = substr ($object , 0, 2);
$mm = substr ($object , 3, 2);
$yy = substr ($object , 6, 4);
$lagerinfo = $mysqli->query("SELECT * FROM `mesto_otd` WHERE LOWER(`Name`) LIKE '%$object%' OR LOWER(`City`) LIKE '%$object%'");

// Уведомление о пустом запросе
if ($object == "") {
}

// Поиск по строке
else {

  while (($row = $lagerinfo->fetch_assoc())!= false){
      echo "<section class=\"Blok2\">";

       echo "<header class=\"header2\"> <h2>Санаторий ".$row["Name"]."</h2></header>";
       echo "<div class=\"Stat2\"> <p><h3>Контактная информация</h3></p>";

    $sql = "SELECT `Adress`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest` FROM `mesto_otd` WHERE LOWER(`Name`) LIKE '%$object%' OR LOWER(`City`) LIKE '%$object%'";
    $sql1 = "SELECT `Period_otd`  FROM `putevka` WHERE `Mesto_otd` = (SELECT `ID` FROM `mesto_otd` WHERE LOWER(`Name`) LIKE '%$object%' OR LOWER(`City`) LIKE '%$object%')";
    $sql2 = "SELECT `Stoimost`  FROM `stoimost` WHERE `ID` = (SELECT `Stoimost` FROM `putevka` WHERE `Mesto_otd` = (SELECT `ID` FROM `mesto_otd` WHERE LOWER(`Name`) LIKE '%$object%' OR LOWER(`City`) LIKE '%$object%'))";
    $sql3 = "SELECT `Name`  FROM `base_components` WHERE `ID` = (SELECT `Base_components` FROM `putevka` WHERE `Mesto_otd` = (SELECT `ID` FROM `mesto_otd` WHERE LOWER(`Name`) LIKE '%$object%' OR LOWER(`City`) LIKE '%$object%'))";
    

    $result = mysqli_query($mysql,$sql);
    $result1 = mysqli_query($mysql,$sql1);
    $result2 = mysqli_query($mysql,$sql2);
    $result3 = mysqli_query($mysql,$sql3);


    $mesto = $result -> fetch_assoc();
    $stoim = $result1 -> fetch_assoc();
    $stoim1 = $result2 -> fetch_assoc();
    $components = $result3 -> fetch_assoc();

    print_r("<p>" ."<b>"."Адрес: " ."</b>".$mesto['Adress'] ."</p>");
    print_r("<p>"."<b>" ."Телефон: " ."</b>".$mesto['Telefon'] ."</p>");
    print_r("<p>" ."<b>"."Способ проезда: " ."</b>".$mesto['Sposob_proezda'] ."</p>");
    print_r("<p>" ."<b>"."Количество отдыхающих: " ."</b>".$mesto['Kol_otd'] ."</p>");
    print_r("<p>" ."<b>"."Осталось мест: " ."</b>".$mesto['Mest'] ."</p>");

    print_r("<p>"."<b>" ."Стоимость курса лечения: " ."</b>"."</p>");
    print_r("<p>"."<b>" ."Курс " .$stoim['Period_otd'] ." дней: " ."</b>".$stoim1['Stoimost'] ."р" ."</p>");

    print_r("<p>" ."<h3>" ."Предоставляемые услуги: " ."</h3>" ."</p>");
    print_r("<p>" .$components['Name'] ."</p>");

      if($_COOKIE['user'] == ''){
         echo "<p><h3>Аторизируйтесь или зарегистрируйтесь на сайте, чтобы забронировать путевку</h3></p>";}
     else {
        echo "<h3><button onclick=\"document.getElementById('id04').style.display='block'\" style=\"width:auto;\" class=\"SignUp\">Забронировать</button></h3>";
    }

    
    echo "</div>";
    echo "</section>";
      }
}


$mysqli->close();

?>
<main>
<section class="Blok2" id='Фортуна'>
<header class="header2">
<h2>Гостевой дом "Фортуна"</h2>
</header>
<div class="Stat1">
	<p><h3>Контактная информация</h3></p>
	<?php

    $mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $sql = "SELECT `Adress`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest` FROM `mesto_otd` WHERE `Name` = 'Фортуна'";
    $sql1 = "SELECT `Period_otd`  FROM `putevka` WHERE `Mesto_otd` = '1'";
    $sql2 = "SELECT `Stoimost`  FROM `stoimost` WHERE `ID` = '1'";
    $sql4 = "SELECT `Name`  FROM `base_components` WHERE `ID` = '1'";

    $result = mysqli_query($mysql,$sql);
    $result1 = mysqli_query($mysql,$sql1);
    $result2 = mysqli_query($mysql,$sql2);
    $result4 = mysqli_query($mysql,$sql4);

    $mesto = $result -> fetch_assoc();
    $stoim = $result1 -> fetch_assoc();
    $stoim1 = $result2 -> fetch_assoc();
    $components = $result4 -> fetch_assoc();

    print_r("<p>" ."<b>"."Адрес: " ."</b>".$mesto['Adress'] ."</p>");
    print_r("<p>"."<b>" ."Телефон: " ."</b>".$mesto['Telefon'] ."</p>");
    print_r("<p>" ."<b>"."Способ проезда: " ."</b>".$mesto['Sposob_proezda'] ."</p>");
    print_r("<p>" ."<b>"."Количество отдыхающих: " ."</b>".$mesto['Kol_otd'] ."</p>");
    print_r("<p>" ."<b>"."Осталось мест: " ."</b>".$mesto['Mest'] ."</p>");

    print_r("<p>"."<b>" ."Стоимость курса лечения: " ."</b>"."</p>");
    print_r("<p>"."<b>" ."Курс " .$stoim['Period_otd'] ." дней: " ."</b>".$stoim1['Stoimost'] ."р" ."</p>");

    print_r("<p>" ."<h3>" ."Предоставляемые услуги: " ."</h3>" ."</p>");
    print_r("<p>" .$components['Name'] ."</p>");
	?>
<?php if($_COOKIE['user'] == ''): ?>
<p><h3>Аторизируйтесь или зарегистрируйтесь на сайте, чтобы забронировать путевку</h3></p>
<?php else: ?>
<h3><button onclick="document.getElementById('id03').style.display='block'" style="width:auto;" class="SignUp">Забронировать
</button></h3>

	<div id="id03" class="modal">
  <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content" action="bron.php" method="post">
<div class="container">
<h1>Бронирование</h1>
<p>Заполните это поле для бронирования путевки.</p>
<hr>

<label for="fio"><b>Укажите фамилию, имя, отчество согласно документу удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите фамилию, имя, отчество согласно документу удостоверяющий личность" name="fio" required>
<label for="doc"><b>Укажите предъявляемый документ удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите предъявляемый документ удостоверяющий личность" name="doc" required>
<label for="tel"><b>Укажите контактный номер телефона</b></label>
<input type="text" placeholder="Укажите контактный номер телефона" name="tel" required>

<label for="kol"><b>Укажите количество бронируемых мест</b></label>
<input type="number" placeholder="Укажите количество бронируемых мест" name="kol" style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1; outline: none;" required>
<label for="date"><b>Укажите дату заезда</b></label>
<input type="date" placeholder="Укажите дату заезда" name="date" required>
<div class="clearfix">
<button type="button" onclick="document.getElementById('id03').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Бронировать</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id03');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>


<?php if($_COOKIE['mesto'] != ''): ?>

    <?php
    $mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $login = filter_var(trim($_COOKIE['user']),FILTER_SANITIZE_STRING);

    $sql1 = "SELECT `Data_zaezda`, `Data_vyezda`, `Kol_put` FROM `turist` WHERE `Login` = '$login'";

    $result1 = mysqli_query($mysql,$sql1);

    $putevka = $result1 -> fetch_assoc();

    $Date1 = date('d-m-Y', strtotime($putevka['Data_zaezda']));
    $Date2 = date('d-m-Y', strtotime($putevka['Data_vyezda']));

    print_r("<p>" ."<b>"."Дата заезда: " ."</b>".$Date1 ."</p>");
    print_r("<p>"."<b>" ."Дата выезда: " ."</b>".$Date2 ."</p>");
    print_r("<p>" ."<b>"."Количество забронированных мест: " ."</b>".$putevka['Kol_put'] ."</p>");
    ?>
    <p><b>Для отмены бронирования позвоните по телефону:</b> 8-918-616-14-15</p>

    
<?php endif; ?>
<?php endif; ?>
</div>

<div class="Img1"><img src="https://cdn5.vedomosti.ru/image/2020/2j/1eg13b/original-1tdl.jpg"></div>
</section>


<section class="Blok2" id='Фрегат'>
<header class="header2">
<h2>Санаторий "Фрегат"</h2>
</header>
<div class="Stat1">
    <p><h3>Контактная информация</h3></p>
    <?php

    $mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $sql = "SELECT `Adress`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest` FROM `mesto_otd` WHERE `Name` = 'Фрегат'";
    $sql1 = "SELECT `Period_otd`  FROM `putevka` WHERE `Mesto_otd` = '2'";
    $sql2 = "SELECT `Stoimost`  FROM `stoimost` WHERE `ID` = '2'";
    $sql4 = "SELECT `Name`  FROM `base_components` WHERE `ID` = '2'";

    $result = mysqli_query($mysql,$sql);
    $result1 = mysqli_query($mysql,$sql1);
    $result2 = mysqli_query($mysql,$sql2);
    $result4 = mysqli_query($mysql,$sql4);

    $mesto = $result -> fetch_assoc();
    $stoim = $result1 -> fetch_assoc();
    $stoim1 = $result2 -> fetch_assoc();
    $components = $result4 -> fetch_assoc();

    print_r("<p>" ."<b>"."Адрес: " ."</b>".$mesto['Adress'] ."</p>");
    print_r("<p>"."<b>" ."Телефон: " ."</b>".$mesto['Telefon'] ."</p>");
    print_r("<p>" ."<b>"."Способ проезда: " ."</b>".$mesto['Sposob_proezda'] ."</p>");
    print_r("<p>" ."<b>"."Количество отдыхающих: " ."</b>".$mesto['Kol_otd'] ."</p>");
    print_r("<p>" ."<b>"."Осталось мест: " ."</b>".$mesto['Mest'] ."</p>");

    print_r("<p>"."<b>" ."Стоимость курса лечения: " ."</b>"."</p>");
    print_r("<p>"."<b>" ."Курс " .$stoim['Period_otd'] ." дней: " ."</b>".$stoim1['Stoimost'] ."р" ."</p>");

    print_r("<p>" ."<h3>" ."Предоставляемые услуги: " ."</h3>" ."</p>");
    print_r("<p>" .$components['Name'] ."</p>");
    ?>
<?php if($_COOKIE['user'] == ''): ?>
<p><h3>Аторизируйтесь или зарегистрируйтесь на сайте, чтобы забронировать путевку</h3></p>
<?php else: ?>
<h3><button onclick="document.getElementById('id04').style.display='block'" style="width:auto;" class="SignUp">Забронировать
</button></h3>

    <div id="id04" class="modal">
  <span onclick="document.getElementById('id04').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content" action="bron1.php" method="post">
<div class="container">
<h1>Бронирование</h1>
<p>Заполните это поле для бронирования путевки.</p>
<hr>

<label for="fio"><b>Укажите фамилию, имя, отчество согласно документу удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите фамилию, имя, отчество согласно документу удостоверяющий личность" name="fio" required>
<label for="doc"><b>Укажите предъявляемый документ удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите предъявляемый документ удостоверяющий личность" name="doc" required>
<label for="tel"><b>Укажите контактный номер телефона</b></label>
<input type="text" placeholder="Укажите контактный номер телефона" name="tel" required>

<label for="kol"><b>Укажите количество бронируемых мест</b></label>
<input type="number" placeholder="Укажите количество бронируемых мест" name="kol" style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1; outline: none;" required>
<label for="date"><b>Укажите дату заезда</b></label>
<input type="date" placeholder="Укажите дату заезда" name="date" required>
<div class="clearfix">
<button type="button" onclick="document.getElementById('id04').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Бронировать</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id04');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>

<?php if($_COOKIE['mesto1'] != ''): ?>

     <?php
    $mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $login = filter_var(trim($_COOKIE['user']),FILTER_SANITIZE_STRING);

    $sql1 = "SELECT `Data_zaezda`, `Data_vyezda`, `Kol_put` FROM `turist` WHERE `Login` = '$login'";

    $result1 = mysqli_query($mysql,$sql1);

    $putevka = $result1 -> fetch_assoc();

    $Date1 = date('d-m-Y', strtotime($putevka['Data_zaezda']));
    $Date2 = date('d-m-Y', strtotime($putevka['Data_vyezda'])); 

    print_r("<p>" ."<b>"."Дата заезда: " ."</b>".$Date1 ."</p>");
    print_r("<p>"."<b>" ."Дата выезда: " ."</b>".$Date2 ."</p>");
    print_r("<p>" ."<b>"."Количество забронированных мест: " ."</b>".$putevka['Kol_put'] ."</p>");

    ?>
    <p><b>Для отмены бронирования позвоните по телефону:</b> 8-918-616-14-15</p>

    
<?php endif; ?>
<?php endif; ?>
</div>

<div class="Img1"><img src="https://www.belokurikha.ru/mvc_images/numbers/2018-06-21-743352018-06-21.jpg"></div>
</section>


<section class="Blok2" id='Дубрава'>
<header class="header2">
<h2>Гостевой дом "Дубрава"</h2>
</header>
<div class="Stat1">
    <p><h3>Контактная информация</h3></p>
    <?php

    $mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
    or die("Ошибка " . mysqli_error($mysql));

    $sql = "SELECT `Adress`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest` FROM `mesto_otd` WHERE `Name` = 'Дубрава'";
    $sql1 = "SELECT `Period_otd`  FROM `putevka` WHERE `Mesto_otd` = '1'";
    $sql2 = "SELECT `Stoimost`  FROM `stoimost` WHERE `ID` = '3'";
    $sql4 = "SELECT `Name`  FROM `base_components` WHERE `ID` = '1'";

    $result = mysqli_query($mysql,$sql);
    $result1 = mysqli_query($mysql,$sql1);
    $result2 = mysqli_query($mysql,$sql2);
    $result4 = mysqli_query($mysql,$sql4);

    $mesto = $result -> fetch_assoc();
    $stoim = $result1 -> fetch_assoc();
    $stoim1 = $result2 -> fetch_assoc();
    $components = $result4 -> fetch_assoc();

    print_r("<p>" ."<b>"."Адрес: " ."</b>".$mesto['Adress'] ."</p>");
    print_r("<p>"."<b>" ."Телефон: " ."</b>".$mesto['Telefon'] ."</p>");
    print_r("<p>" ."<b>"."Способ проезда: " ."</b>".$mesto['Sposob_proezda'] ."</p>");
    print_r("<p>" ."<b>"."Количество отдыхающих: " ."</b>".$mesto['Kol_otd'] ."</p>");
    print_r("<p>" ."<b>"."Осталось мест: " ."</b>".$mesto['Mest'] ."</p>");

    print_r("<p>"."<b>" ."Стоимость курса лечения: " ."</b>"."</p>");
    print_r("<p>"."<b>" ."Курс " .$stoim['Period_otd'] ." дней: " ."</b>".$stoim1['Stoimost'] ."р" ."</p>");

    print_r("<p>" ."<h3>" ."Предоставляемые услуги: " ."</h3>" ."</p>");
    print_r("<p>" .$components['Name'] ."</p>");
    ?>
<?php if($_COOKIE['user'] == ''): ?>
<p><h3>Аторизируйтесь или зарегистрируйтесь на сайте, чтобы забронировать путевку</h3></p>
<?php else: ?>
<h3><button onclick="document.getElementById('id03').style.display='block'" style="width:auto;" class="SignUp">Забронировать
</button></h3>

    <div id="id03" class="modal">
  <span onclick="document.getElementById('id03').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content" action="bron2.php" method="post">
<div class="container">
<h1>Бронирование</h1>
<p>Заполните это поле для бронирования путевки.</p>
<hr>

<label for="fio"><b>Укажите фамилию, имя, отчество согласно документу удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите фамилию, имя, отчество согласно документу удостоверяющий личность" name="fio" required>
<label for="doc"><b>Укажите предъявляемый документ удостоверяющий личность</b></label>
<input type="text" placeholder="Укажите предъявляемый документ удостоверяющий личность" name="doc" required>
<label for="tel"><b>Укажите контактный номер телефона</b></label>
<input type="text" placeholder="Укажите контактный номер телефона" name="tel" required>

<label for="kol"><b>Укажите количество бронируемых мест</b></label>
<input type="number" placeholder="Укажите количество бронируемых мест" name="kol" style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1; outline: none;" required>
<div class="clearfix">
<button type="button" onclick="document.getElementById('id03').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Бронировать</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id03');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>



<?php endif; ?>
</div>
<?php if($_COOKIE['mesto'] != ''): ?>
<?php endif; ?>
<div class="Img1"><img src="https://photo.kurortmag.ru/photo.ashx/54653226/0/"></div>
</section>


</main>
<footer>
<div class="nav">
<a href="Index.htm">Главная</a>
<a href="#">Каталог санаториев</a>
<a href="Контакты.php">Контакты</a>
<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="SignUp">Авторизация
</button>
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="SignUp">Регистрация
</button>
</div>
</footer>
</body>
</html>
