<?php

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));


if($_COOKIE['user'] != '') {
$login = filter_var(trim($_COOKIE['user']),
FILTER_SANITIZE_STRING);
}

$sql = "SELECT `Mest` FROM `mesto_otd` WHERE `Name` = 'Фортуна'";

$result = mysqli_query($mysql,$sql);
$kol_mest = $result -> fetch_assoc();

$kol = filter_var(trim($_COOKIE['kol']),
FILTER_SANITIZE_STRING);

$kol1 = $kol_mest['Mest'] + $kol;


$mysql -> query("UPDATE `mesto_otd` SET `Mest` = '$kol1' WHERE `Name` = 'Фортуна'");
$mysql -> query("DELETE FROM `turist` WHERE `turist`.`Login` = '$login'");

mysqli_close($mysql);

header('Location: Каталог санаториев.php');

?>