<?php

$fio = filter_var(trim($_POST['fio']),
FILTER_SANITIZE_STRING);
$doc = filter_var(trim($_POST['doc']),
FILTER_SANITIZE_STRING);
$tel = filter_var(trim($_POST['tel']),
FILTER_SANITIZE_STRING);
$kol = filter_var(trim($_POST['kol']),
FILTER_SANITIZE_STRING);
$dat = filter_var(trim($_POST['date']),
FILTER_SANITIZE_STRING);
	
if(mb_strlen($fio) < 2 || mb_strlen($fio) > 120) {
echo "Недопустимая длина имени пользователя";
exit();
} else if(mb_strlen($doc) < 2 || mb_strlen($doc) > 90) {
echo "Недопустимая длина документа удостоверяющего личность";
exit();} else if(mb_strlen($tel) < 11 || mb_strlen($tel) > 16) {
echo "Недопустимая длина телефона";
exit();}

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));

$sql = "SELECT `Mest` FROM `mesto_otd` WHERE `Name` = 'Фортуна'";

$result = mysqli_query($mysql,$sql);
$mest_ost = $result -> fetch_assoc();

if($mest_ost < $kol)
{
	echo "Нет такого количеста мест";
	print_r("<p>" ."Осталось мест: " .$mest_ost['Mest'] ."</p>");
	exit();
} else {
	$ost = $mest_ost['Mest'] - $kol;
	if($ost < 0) {
		echo "Нет такого количеста мест";
	print_r("<p>" ."Осталось мест: " .$mest_ost['Mest'] ."</p>");
	exit();
	} else {
	$mysql -> query("UPDATE `mesto_otd` SET `Mest`= '$ost' WHERE `Name` = 'Фортуна'");
}
}

$dat1 = new DateTime($dat);
$dat1->add(new DateInterval('P14D')); 
$Date1 = $dat1->format('Y-m-d');


if($_COOKIE['user'] != '') {
$login = filter_var(trim($_COOKIE['user']),
FILTER_SANITIZE_STRING);
}


$sql1 = "SELECT `Login`, `E-mail` FROM `user` WHERE `Login` = '$login'";

$result1 = mysqli_query($mysql,$sql1);


$user = $result1 -> fetch_assoc();

$Email = $user['E-mail'];

$mysql -> query("INSERT INTO `turist` (`Login`, `E-mail`, `FIO`, `Document`, `Telefon`, `Putevka`, `Mesto_otd`, `Data_zaezda`, `Data_vyezda`, `Kol_put`) VALUES('$login', '$Email', '$fio', '$doc', '$tel', '1', '1', '$dat', '$Date1', $kol)");

$sql2 = "SELECT `FIO` FROM `turist` WHERE `Login` = '$login'";
$result2 = mysqli_query($mysql,$sql2);
$user1 = $result2 -> fetch_assoc();

setcookie('mesto', $mest_ost['Mest'], time() + 5, "/");

mysqli_close($mysql);
header('Location: Каталог санаториев.php');

?>