<?php
include('Каталог санаториев.php');

$psw = filter_var(trim($_POST['psw']),
FILTER_SANITIZE_STRING);

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));

$result = $mysql -> query("SELECT * FROM `passwords` WHERE `Passwords` = '$psw'");
$user = $result -> fetch_assoc();


setcookie('psw', $user['Passwords'], time() + 5, "/");

mysqli_close($mysql);

header('Location: Каталог санаториев.php');
?>