<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Контакты</title>
<link rel="stylesheet" type="text/css" href="Lab_1.css">
</head>
<body>
<header class="Header">
<div class="Name"><h1>ЛУЧШИЕ САНАТОРИИ ЮГА РОССИИ</h1></div>
<div class="nav">
<a href="Index.htm">Главная</a>
<a href="Каталог санаториев.php">Каталог санаториев</a>
<a href="#">Контакты</a>
<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="SignUp">Авторизация
</button>
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="SignUp">Регистрация
</button>
</div>

<div id="id01" class="modal">
<span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">×</span>
<form class="modal-content" action="
registration.php" method="post">
<div class="container">
<h1>Регистрация</h1>
<p>Заполните эти поля для создания аккаунта.</p>
<hr>
<label for="login"><b>Логин</b></label>
<input type="text" placeholder="Введите логин" name="login" required>

<label for="psw"><b>Пароль</b></label>
<input type="password" placeholder="Введите пароль" name="psw" required style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1;">
     
<label for="email"><b>Адрес электронной почты</b></label>
<input type="email" placeholder="Введите адрес электронной почты" name="email" required>
<div class="clearfix">
<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Регистрация</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id01');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>

<div id="id02" class="modal">
<span onclick="document.getElementById('id02').style.display='none'" class="close" title="Close Modal">×</span>

<form class="modal-content" action="authorization.php" method="post">
<div class="container">
<h1>Авторизация</h1>
<p>Пожалуйста заполните эти поля для входа в аккаунт.</p>
<hr>
<label for="login"><b>Введите логин</b></label>
<input type="text" placeholder="Введите логин" name="login" required>

<label for="psw"><b>Пароль</b></label>
<input type="password" placeholder="Введите пароль" name="psw" required style="width: 100%; padding: 15px; margin: 5px 0 22px 0; display: inline-block; border: none; background: #f1f1f1;">

<div class="clearfix">
<button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn">Выход</button>
<button type="submit" class="signupbtn">Авторизация</button>
</div>
</div>
</form>
</div>
<script>
let modal = document.getElementById('id02');
window.onclick = function(event) {
if (event.target == modal) {
modal.style.display = "none";
}
}
</script>
</header>
<main>
<div class="Blok1">
<h2>Наши контакты</h2>
<p>Позвоните по телефону:</p>
<ul style="text-align: left; font-size: 20px;">
	<li>Москва: 8-918-616-14-13</li>
	<li>Ростов на Дону: 8-918-616-14-14</li>
	<li>Новочеркасск: 8-918-616-14-15</li>
</ul>
<p>Написать нам на почту: bestsanarories@mail.ru</p>
<p>Посетить нас по адресу:</p>
<ul style="text-align: left; font-size: 20px;">
	<li>Москва: ул. Малиновая 8</li>
	<li>Ростов на Дону: ул. Революции 9</li>
	<li>Новочеркасск: ул. Московская 17</li>
</ul>
<p>Если вы хотите добавить свой санаторий к нам на сайт, пожалуйста позвоните по одному из указанных номеров или отправте сообщение к нам на почту</p>
</div>
</main>
<footer>
<div class="nav">
<a href="Index.htm">Главная</a>
<a href="Каталог санаториев.php">Каталог санаториев</a>
<a href="#">Контакты</a>
<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="SignUp">Авторизация
</button>
<button onclick="document.getElementById('id01').style.display='block'" style="width:auto;" class="SignUp">Регистрация
</button>
</div>
</footer>
</body>
</html>
