<?php

$login = filter_var(trim($_POST['login']),
FILTER_SANITIZE_STRING);
$psw = filter_var(trim($_POST['psw']),
FILTER_SANITIZE_STRING);
$email = filter_var(trim($_POST['email']),
FILTER_SANITIZE_STRING);

if(mb_strlen($login) < 2 || mb_strlen($login) > 90) {
echo "Недопустимая длина имени пользователя";
exit();
} else if(mb_strlen($psw) < 4 || mb_strlen($psw) > 30) {
echo "Недопустимая длина пароля";
exit(); }

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));

$mysql -> query("INSERT INTO `user` (`Login`, `Password`, `E-mail`) VALUES('$login', '$psw', '$email')");

$result = $mysql -> query("SELECT * FROM `user` WHERE `Login`='$login' AND `Password` = '$psw'");
$user = $result -> fetch_assoc();

setcookie('user', $user['Login'], time() + 3600, "/");

setcookie('psw', $user['Password'], time() + 3600, "/");

mysqli_close($mysql);

header('Location: Каталог санаториев.php');
?>
