-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 26 2021 г., 22:24
-- Версия сервера: 5.7.29-log
-- Версия PHP: 7.1.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `bronirovanie`
--

-- --------------------------------------------------------

--
-- Структура таблицы `admin`
--

CREATE TABLE `admin` (
  `ID` int(11) NOT NULL,
  `Login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `admin`
--

INSERT INTO `admin` (`ID`, `Login`, `Password`) VALUES
(1, 'Jin', '19735');

-- --------------------------------------------------------

--
-- Структура таблицы `base_components`
--

CREATE TABLE `base_components` (
  `ID` int(11) NOT NULL,
  `Name` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `base_components`
--

INSERT INTO `base_components` (`ID`, `Name`) VALUES
(1, 'Бани, спа, йога, бассейн, прогулки на свежем воздухе, соляные ванные '),
(2, 'Составление персональной диеты, курсы медитации, бани, спа, массажи, фитнес центр, кинотеатр, комната тишины');

-- --------------------------------------------------------

--
-- Структура таблицы `data_zaezda`
--

CREATE TABLE `data_zaezda` (
  `ID` int(11) NOT NULL,
  `Data_zaezda` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `data_zaezda`
--

INSERT INTO `data_zaezda` (`ID`, `Data_zaezda`) VALUES
(1, '2020-11-01'),
(2, '2020-11-15');

-- --------------------------------------------------------

--
-- Структура таблицы `mesto_otd`
--

CREATE TABLE `mesto_otd` (
  `ID` int(11) NOT NULL,
  `Name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Adress` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `City` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telefon` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Sposob_proezda` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Kol_otd` int(11) NOT NULL,
  `Mest` int(11) UNSIGNED NOT NULL,
  `Data_zaezda` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `mesto_otd`
--

INSERT INTO `mesto_otd` (`ID`, `Name`, `Adress`, `City`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest`, `Data_zaezda`) VALUES
(1, 'Фортуна', 'Ростовская область, город Таганрог, улица Малиновая 8', 'Таганрог', '+7-980-480-17-23', 'Городской общественный транспорт: автобус 11, остановка \"Фортуна\"', 150, 7, 1),
(2, 'Фрегат', 'Краснодарский край, город Анапа, улица Селезнева 17\r\n\r\n', 'Анапа', '+7-988-570-71-22', 'Городской общественный транспорт: автобус 5, остановка \"Фрегат\"', 300, 15, 2),
(8, 'Дубрава', 'Краснодарский край, поселок Дубовый, улица Лесная 20', 'Дубовый', '89181873745', 'Городской общественный транспорт: автобус 1, 8, 30, остановка Дубрава', 110, 36, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `passwords`
--

CREATE TABLE `passwords` (
  `ID` int(11) NOT NULL,
  `Passwords` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `passwords`
--

INSERT INTO `passwords` (`ID`, `Passwords`) VALUES
(1, '123456'),
(2, '456789'),
(3, '789123'),
(4, '123789'),
(5, '456456');

-- --------------------------------------------------------

--
-- Структура таблицы `putevka`
--

CREATE TABLE `putevka` (
  `ID` int(11) NOT NULL,
  `Name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Period_otd` int(11) NOT NULL,
  `Mesto_otd` int(11) NOT NULL,
  `Stoimost` int(11) NOT NULL,
  `Base_components` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `putevka`
--

INSERT INTO `putevka` (`ID`, `Name`, `Period_otd`, `Mesto_otd`, `Stoimost`, `Base_components`) VALUES
(1, 'Лечебная 1', 14, 1, 1, 1),
(2, 'Лечебная 2', 28, 2, 2, 2),
(3, 'Лечебная 3', 21, 8, 3, 1);

-- --------------------------------------------------------

--
-- Структура таблицы `stoimost`
--

CREATE TABLE `stoimost` (
  `ID` int(11) NOT NULL,
  `Stoimost` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `stoimost`
--

INSERT INTO `stoimost` (`ID`, `Stoimost`) VALUES
(1, 17000),
(2, 20000),
(3, 21000);

-- --------------------------------------------------------

--
-- Структура таблицы `turist`
--

CREATE TABLE `turist` (
  `ID` int(11) NOT NULL,
  `Login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `E-mail` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `FIO` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Document` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Telefon` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `Putevka` int(11) NOT NULL,
  `Mesto_otd` int(11) NOT NULL,
  `Data_zaezda` date NOT NULL,
  `Data_vyezda` date NOT NULL,
  `Kol_put` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `turist`
--

INSERT INTO `turist` (`ID`, `Login`, `E-mail`, `FIO`, `Document`, `Telefon`, `Putevka`, `Mesto_otd`, `Data_zaezda`, `Data_vyezda`, `Kol_put`) VALUES
(73, 'Nik', 'nik@gmail.ru', 'Петрова Анна  Андреевна', 'Паспорт', '89183651745', 2, 2, '2021-02-01', '2021-03-01', 3),
(89, 'Leo', 'leo@mail.ru', 'Лобанова Инна Андреевна', 'Паспорт', '89183651666', 1, 1, '2021-02-01', '2021-02-15', 2);

-- --------------------------------------------------------

--
-- Структура таблицы `user`
--

CREATE TABLE `user` (
  `ID` int(11) NOT NULL,
  `Login` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Password` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `E-mail` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `user`
--

INSERT INTO `user` (`ID`, `Login`, `Password`, `E-mail`) VALUES
(1, 'Leo', '12345', 'leo@mail.ru'),
(2, 'Nik', '6789', 'nik@gmail.ru'),
(3, 'Sunny', '9876', 'sun@gmail.ru'),
(9, 'Jin', '19735', 'lego@mail.ru'),
(11, 'Rosa', '147258', 'Rosa@mail.ru'),
(12, '89889520973', '2025', 'oleynikir@mail.ru');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `base_components`
--
ALTER TABLE `base_components`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `data_zaezda`
--
ALTER TABLE `data_zaezda`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `mesto_otd`
--
ALTER TABLE `mesto_otd`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Data_zaezda` (`Data_zaezda`);

--
-- Индексы таблицы `passwords`
--
ALTER TABLE `passwords`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `putevka`
--
ALTER TABLE `putevka`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Mesto_otd` (`Mesto_otd`),
  ADD KEY `Stoimost` (`Stoimost`),
  ADD KEY `putevka_ibfk_3` (`Base_components`);

--
-- Индексы таблицы `stoimost`
--
ALTER TABLE `stoimost`
  ADD PRIMARY KEY (`ID`);

--
-- Индексы таблицы `turist`
--
ALTER TABLE `turist`
  ADD PRIMARY KEY (`ID`),
  ADD KEY `Putevka` (`Putevka`,`Mesto_otd`),
  ADD KEY `Mesto_otd` (`Mesto_otd`);

--
-- Индексы таблицы `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`ID`),
  ADD UNIQUE KEY `Password` (`Password`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `admin`
--
ALTER TABLE `admin`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT для таблицы `base_components`
--
ALTER TABLE `base_components`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `data_zaezda`
--
ALTER TABLE `data_zaezda`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `mesto_otd`
--
ALTER TABLE `mesto_otd`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT для таблицы `passwords`
--
ALTER TABLE `passwords`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `putevka`
--
ALTER TABLE `putevka`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `stoimost`
--
ALTER TABLE `stoimost`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `turist`
--
ALTER TABLE `turist`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=90;

--
-- AUTO_INCREMENT для таблицы `user`
--
ALTER TABLE `user`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `mesto_otd`
--
ALTER TABLE `mesto_otd`
  ADD CONSTRAINT `mesto_otd_ibfk_1` FOREIGN KEY (`Data_zaezda`) REFERENCES `data_zaezda` (`ID`);

--
-- Ограничения внешнего ключа таблицы `putevka`
--
ALTER TABLE `putevka`
  ADD CONSTRAINT `putevka_ibfk_1` FOREIGN KEY (`Mesto_otd`) REFERENCES `mesto_otd` (`ID`),
  ADD CONSTRAINT `putevka_ibfk_2` FOREIGN KEY (`Stoimost`) REFERENCES `stoimost` (`ID`),
  ADD CONSTRAINT `putevka_ibfk_3` FOREIGN KEY (`Base_components`) REFERENCES `base_components` (`ID`);

--
-- Ограничения внешнего ключа таблицы `turist`
--
ALTER TABLE `turist`
  ADD CONSTRAINT `turist_ibfk_1` FOREIGN KEY (`Mesto_otd`) REFERENCES `mesto_otd` (`ID`),
  ADD CONSTRAINT `turist_ibfk_2` FOREIGN KEY (`Putevka`) REFERENCES `putevka` (`ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
