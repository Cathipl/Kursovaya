<?php

$name = filter_var(trim($_POST['login']),
FILTER_SANITIZE_STRING);
$adres = filter_var(trim($_POST['adres']),
FILTER_SANITIZE_STRING);
$tel = filter_var(trim($_POST['tel']),
FILTER_SANITIZE_STRING);
$sposob = filter_var(trim($_POST['sposob']),
FILTER_SANITIZE_STRING);
$kol = filter_var(trim($_POST['kol']),
FILTER_SANITIZE_STRING);
$date = filter_var(trim($_POST['date']),
FILTER_SANITIZE_STRING);
	
if(mb_strlen($name) < 2 || mb_strlen($name) > 120) {
echo "Недопустимая длина имени пользователя";
exit();
} else if($kol <= 0) {
echo "Количество мест не может быть меньше 0";
exit(); } else if(mb_strlen($adres) < 2 || mb_strlen($adres) > 390) {
echo "Недопустимая длина адреса";
exit();} else if(mb_strlen($tel) < 11 || mb_strlen($tel) > 16) {
echo "Недопустимая длина телефона";
exit();} else if(mb_strlen($sposob) < 2 || mb_strlen($sposob) > 260) {
echo "Недопустимая длина способа проезда";
exit();}

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));

$mysql -> query("INSERT INTO `mesto_otd` (`Name`, `Adress`, `Telefon`, `Sposob_proezda`, `Kol_otd`, `Mest`, `Data_zaezda`) VALUES('$name', '$adres', '$tel', '$sposob', '$kol', '$kol', '1')");

$sql1 = "SELECT `Name` FROM `mesto_otd` WHERE `Name` = '$name'";

$result1 = mysqli_query($mysql,$sql1);
$mest_ost = $result1 -> fetch_assoc();

setcookie('mesto_otd', $mest_ost['Name'], time() + 20, "/");
mysqli_close($mysql);
header('Location: Контакты.php');

?>