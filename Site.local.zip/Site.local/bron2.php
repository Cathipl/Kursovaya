<?php

$fio = filter_var(trim($_POST['fio']),
FILTER_SANITIZE_STRING);
$doc = filter_var(trim($_POST['doc']),
FILTER_SANITIZE_STRING);
$tel = filter_var(trim($_POST['tel']),
FILTER_SANITIZE_STRING);
$kol = filter_var(trim($_POST['kol']),
FILTER_SANITIZE_STRING);
	
if(mb_strlen($fio) < 2 || mb_strlen($fio) > 120) {
echo "Недопустимая длина имени пользователя";
exit();
} else if(mb_strlen($doc) < 2 || mb_strlen($doc) > 90) {
echo "Недопустимая длина документа удостоверяющего личность";
exit();} else if(mb_strlen($tel) < 11 || mb_strlen($tel) > 16) {
echo "Недопустимая длина телефона";
exit();}

$mysql = mysqli_connect('localhost', 'mysql', 'mysql', 'bronirovanie')
or die("Ошибка " . mysqli_error($mysql));

$sql = "SELECT `Mest` FROM `mesto_otd` WHERE `Name` = 'Дубрава'";

$result = mysqli_query($mysql,$sql);
$mest_ost = $result -> fetch_assoc();

if($mest_ost < $kol)
{
	echo "Нет такого количеста мест";
	print_r("<p>" ."Осталось мест: " .$mest_ost['Mest'] ."</p>");
	exit();
} else {
	$ost = $mest_ost['Mest'] - $kol;
	if($ost < 0) {
		echo "Нет такого количеста мест";
	print_r("<p>" ."Осталось мест: " .$mest_ost['Mest'] ."</p>");
	exit();
	} else {
	$mysql -> query("UPDATE `mesto_otd` SET `Mest`= '$ost' WHERE `Name` = 'Дубрава'");
}
}


$mysql -> query("INSERT INTO `turist` (`FIO`, `Document`, `Telefon`, `Putevka`, `Mesto_otd`) VALUES('$fio', '$doc', '$tel', '3', '8')");

setcookie('mesto2', $mest_ost['Mest'], time() + 3600, "/");
mysqli_close($mysql);
header('Location: Каталог санаториев.php');

?>